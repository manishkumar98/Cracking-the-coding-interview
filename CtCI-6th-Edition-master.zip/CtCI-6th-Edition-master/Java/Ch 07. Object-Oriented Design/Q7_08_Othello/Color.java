package Q7_08_Othello;

public enum Color {
	White, Black
}
