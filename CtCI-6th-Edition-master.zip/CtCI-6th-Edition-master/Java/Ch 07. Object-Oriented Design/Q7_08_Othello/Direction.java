package Q7_08_Othello;

public enum Direction {
	left, right, up, down
}
