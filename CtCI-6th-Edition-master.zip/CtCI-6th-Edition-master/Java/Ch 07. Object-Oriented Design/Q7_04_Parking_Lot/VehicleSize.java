package Q7_04_Parking_Lot;

public enum VehicleSize {
	Motorcycle, 
	Compact, 
	Large,
}
