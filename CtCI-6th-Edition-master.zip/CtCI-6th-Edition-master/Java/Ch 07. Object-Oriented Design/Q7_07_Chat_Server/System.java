package Q7_07_Chat_Server;

public class System {

}
