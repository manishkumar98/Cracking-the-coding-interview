package Q16_14_Best_Line;

public class GraphPoint {
	public double x;
	public double y;
	public GraphPoint(double x1, double y1) {
		x = x1;
		y = y1;
	}
	
	public String toString() {
		return "(" + x + ", " + y + ")";
	}
}
